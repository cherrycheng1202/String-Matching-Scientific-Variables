import Rule_KeysMatching
import String_CleaningUp
import Rule_DataRangeMatching
import Rule_RecordMatching
import Rule_UnitMatching
import Dictionary_Reading
import Record_Modifying
import Rule_UnitGuessing


def search(input_str, input_data, input_unit):
    sug_list = []

    # -------------------------------- Dictionaries Reading ------------------------------------
    # Call function Dictionary_API.create_vocab_dictionary() to get a list of vocabularies
    #   >> The format of this vocabs list would be ['@Vocab1 Unit 1': ['Vocab', 'link', 'unit'],
    #      '@Vocab1 Unit 2': ['Vocab', 'link', 'unit'], ..., '@Vocab1 Unit n': ['Vocab', 'link', 'unit']]
    # Call the function Dictionary_Reading.read_units() to get a list of units
    #   >> The format of the units in this list would be 'Unit': [['Symbol 1', 'Symbol 2', ..., 'Symbol n'], 'Link']
    # ------------------------------------------------------------------------------------------
    my_dict = Dictionary_Reading.read_vocabs('vocab_dictionary.json')
    unit_dict = Dictionary_Reading.read_simple_json('units_of_measure.json')

    # -------------------------------- Metadata Cleaning ---------------------------------------
    # The input metadata may be formed by multiple keywords, e.g. 'MaxAirTemp'
    # Call function String_CleaningUp.cleaning_up_metadata() to clean the input metadata, e.g. ['Max', 'Air', 'Temp']
    # The format of the return cleaned metadata list would be
    # [['Keyword 1', 'Keyword 2', ..., 'Keyword n'], Value, 'Full name of the unit', ['Must-include keywords'],
    # ['Minor keywords']]
    # ------------------------------------------------------------------------------------------
    metadata_li = String_CleaningUp.cleaning_up_metadata(input_str, input_data, input_unit)
    # print(metadata_li)

    # -------------------------------- Minimum priority num ------------------------------------
    # The vocab must have its score higher than the min_priority_num to be shown in the final list
    # The basic min_priority_num equal to the number of words in the metadata.
    #   >> e.g. "WaterTemp": min_priority_num = 2
    # If the user had provided a unit, the min_priority_num will be increased by 1
    # If there are any minor keywords that may not need to be included in the vocabulary, the min_priority_num will be
    # decreased by the number of minor keywords
    #   >> e.g. metadata = 'SoilTemp 10cm'
    #   >>      minor_keywords = ['10cm']
    #   >>      min_priority_num = 3 - 1 = 2
    # ------------------------------------------------------------------------------------------
    min_priority_num = len(metadata_li[0])
    if input_unit != '':
        min_priority_num += 1
    min_priority_num -= len(metadata_li[4])

    # ---------------------------------- Rule Keys Matching ------------------------------------
    # Call function Rule_KeysMatching.key_matching()
    # Append the result to the bridge list for each dictionary
    # Each vocab in the returned list has the format ['@Vocab Unit', 'Vocab', 'Link', 'Unit', Priority Num]
    # Only the vocabs that have the priority num > 0 would be included in this list
    # ------------------------------------------------------------------------------------------
    bridge = Rule_KeysMatching.key_matching(metadata_li[0], my_dict, metadata_li[3])
    result = bridge

    # -------------------------------- Rule Data Range Matching --------------------------------
    # If the user entered the value:
    # Call function Rule_DataRangeMatching.data_matching()
    # The format of the vocabs list remains unchanged after the function is called
    # The only element changed by this function is the priority num of the vocabs
    # ------------------------------------------------------------------------------------------
    if input_data != '':
        bridge = Rule_DataRangeMatching.data_matching(result, metadata_li[1], metadata_li[2])
        result = bridge

    # ----------------------------------- Rule Unit guessing -----------------------------------
    # If the user entered a value but have no unit:
    # Call function Rule_UnitGuessing.guess_unit()
    # The format of the vocabs list remains unchanged after the function is called
    # The only element changed by this function is the priority num of the vocabs
    # ------------------------------------------------------------------------------------------
    if input_unit == '' and input_data != '':
        bridge = Rule_UnitGuessing.guess_unit(result, metadata_li[0], metadata_li[1])
        result = bridge

    # -------------------------------- Rule Unit Matching --------------------------------------
    # If there is a unit in the metadata,
    # Call function Rule_UnitMatching.unit_matching()
    # The format of the vocabs list remains unchanged after the function is called
    # The only element changed by this function is the priority num of the vocabs
    # ------------------------------------------------------------------------------------------
    if metadata_li[2] != ['none']:
        bridge = Rule_UnitMatching.unit_matching(result, metadata_li[2])
        result = bridge

    # ------------------------------ Rule Record Matching --------------------------------------
    # Call function Rule_RecordMatching.record_matching()
    # The format of the vocabs list remains unchanged after the function is called
    # The only element changed by this function is the priority num of the vocabs
    # ------------------------------------------------------------------------------------------
    bridge = Rule_RecordMatching.record_matching(result, metadata_li[0], input_unit)
    result = bridge

    # --------------------------------- Return the result --------------------------------------
    # If no vocab can be found, return ['No result']
    # Else
    #   1. Sorted the vocabs from the list by their priority num, put the vocab with highest num at the front
    #   2. Identify which vocabs from the list should be included in the final suggestions list
    #   3. Get the link of the unit from unit_dict and append this link to the vocab
    #      >> From ['@Vocab Unit', 'Vocab', 'Link', 'Unit', Priority Num]
    #      >> To ['@Vocab Unit', 'Vocab', 'Link', 'Unit', Priority Num, 'Unit Link"]
    #   4. Return the final suggestions list
    # ------------------------------------------------------------------------------------------
    if not result:
        return [metadata_li, 'No result']
    else:
        count = 1
        vocabs_list = sorted(result, key=lambda x: x[4], reverse=True)

        for vocab in vocabs_list:
            if vocab[4] >= min_priority_num:
                sug_list.append([count, vocab[1], vocab[2], vocab[3], vocab[4]])
                count += 1

        if not sug_list:
            return [metadata_li, 'No result']
        else:
            for r in sug_list:
                if r[3] in unit_dict.keys():
                    r.append(unit_dict[r[3]][1])
                else:
                    r.append('')
            return [metadata_li, sug_list]


# ---------------------------------- Choice Recording --------------------------------------
# If the user chose the vocab that they through it was best matched to the metadata they had
# input, this function is called
# Call function Record_Modifying.record_modifying() to record the choice
# ------------------------------------------------------------------------------------------
def choice_recording(keys_list, a_unit, vocab, unit):
    Record_Modifying.record_modifying(keys_list, a_unit, vocab, unit)


# ------------------------------- Metadata formalization -----------------------------------
# INPUT: text_list (the metadata), vocab (the vocab from the dictionary), unit (unit of the vocab)
# OUTPUT: full_name (the formalized metadata)
#
# Read the JSON file that stored the adj
# Check if the metadata contains any of the adj
# Format of the output string: Adj Vocab in Unit (if any)
# ------------------------------------------------------------------------------------------
def form_formal_text(text_list, vocab, unit):
    adj_list = Dictionary_Reading.read_simple_json('minor_Keys.json')
    full_name = vocab

    for word in text_list:
        if word.lower() not in vocab.lower():
            for key in adj_list:
                for short_key in adj_list[key]:
                    if word.lower() == short_key.lower() or word.lower() == key.lower():
                        full_name = key + ' ' + vocab
                        break
                if full_name != vocab:
                    break
    full_name += (' in ' + unit) if unit != 'none' else ''
    return full_name


# ------------------------------- Ask for inputs from user -------------------------------
# To end the program, leave the input for the "Name: " empty and press "Enter"
# If the user did not input anything for the 'Name', break the loop
# Take the name, value and unit from the user
# Call function search() to get a vocabs list
# Call function form_formal_text() to have a nicer description of each vocab
# Print out the result
# ----------------------------------------------------------------------------------------
while True:
    a = input("Name: ").rstrip()
    if a == '':
        break
    b = input("value: ").rstrip()
    c = input("unit: ").rstrip()
    result_list = search(a, b, c)

    if result_list[1] == 'No result':
        print('No result')
    else:
        for line in result_list[1]:
            formal_name = form_formal_text(result_list[0][0], line[1], line[3])
            print(line[0], formal_name, "[", line[1], "(" + line[2] + ")", line[3], "(" + line[5] + ")", "]")

        choice = input("Best match: ").rstrip()
        try:
            cho = int(choice)
            choice_recording(result_list[0][0], c, result_list[1][cho - 1][1], result_list[1][cho - 1][3])

        except:
            print("Nothing is selected")

    print('------------------------------------------------------')
