# import sys
# from random import randint
# import urllib
# # from bs4 import beautifulsoup
# from operator import itemgetter
#
#
# ## ----------------------- Class Testing -------------------------
# # class Vocab:
# #     def __init__(self, name, link, chosen):
# #         self.name = name
# #         self.link = link
# #         self.chosen = chosen
#
# ## --------------------- Read Text File -------------------------
#
# # read rule sets file
#
# try:
#     openFile = open("outpost_observed_properties.txt")
#     openRuleSets = open("ruleSets.txt")
# except FileNotFoundError:
#     print("File not found")
#     sys.exit()
#
# myList = []
# rulesetList = []
# ruleNum = {}
#
#
# for line in openRuleSets:
#     rulesetList.append(line.strip())
#
# ruleList = [{} for i in range(len(rulesetList))]
#
# i = 0
# for name in rulesetList:
#     try:
#         openRules = open(name)
#         key2 = name.split('.')
#         ruleNum[key2[0]] = i
#     except FileNotFoundError:
#         print("File not found")
#         sys.exit()
#
#     if openRules:
#         for r in openRules:
#             rule = r.strip().split('__')
#             key = rule[0]
#
#             ruleList[i][key] = rule[1:len(rule)]
#
#         i += 1
#     openRules.close()
#
# # print(ruleList)
# # print(ruleNum)
#
# for line in openFile:
#     myList.append(line)
#
# openFile.close()
# openRuleSets.close()
#
# vocabLibrary = []
# resultList = []
# #
# # for item in myList:
# #     a = item.split(':')
# #     if a[0].strip() not in vocabLibrary:
# #         vocabLibrary.append(a[0].strip())
# #     if a[1].strip() not in resultList:
# #         resultList.append(a[1].strip())
# #
# # print(len(vocabLibrary))
#
# myDictionary = {}
#
# for item in myList:
#     a = item.split(':')
#     if a[0] not in myDictionary.keys():
#         myDictionary[a[0].strip()] = ['https://... ', randint(0, 20)]
#
#
# #
# #
# # mylist = []
# # vocab1 = Vocab("Env Pro Moisture 10cm", "link1", 6, 2)
# # vocab4 = Vocab("Env Pro Moisture 20cm", "link4", 6, 2)
# # vocab5 = Vocab("Env Pro Moisture 30cm", "link5", 6, 2)
# # vocab6 = Vocab("Env Pro Moisture 40cm", "link6", 6, 2)
# # vocab7 = Vocab("Env Pro Moisture 50cm", "link7", 6, 2)
# # vocab8 = Vocab("Env Pro Moisture 60cm", "link8", 6, 2)
# # vocab9 = Vocab("Env Pro Moisture 70cm", "link9", 6, 2)
# # vocab2 = Vocab("Env Pro Salinity 30cm", "link2", 5, 1)
# # vocab3 = Vocab("TBSHT01 Humidity", "link3", 0, 0)
# # vocab10 = Vocab("Env Pro Salinity 70cm", "link2", 5, 1)
# #
# # mylist.append(vocab1)
# # mylist.append(vocab2)
# # mylist.append(vocab3)
# # mylist.append(vocab4)
# # mylist.append(vocab5)
# # mylist.append(vocab6)
# # mylist.append(vocab7)
# # mylist.append(vocab8)
# # mylist.append(vocab9)
# # mylist.append(vocab10)
# #
# # fileOpen = open("testing1Vocab.txt", "w")
# #
# # for line in mylist:
# #     fileOpen.write(line.name + ":" + line.link + ":" + str(line.suggested) + ":" + str(line.chosen) + "\n")
# #
# # fileOpen.close()
#
#
# ## ----------------------- Single Input Testing -------------------------
# # # mydictionary = {"a": "123", "b": "234", "c": "3456"}
# # mydictionary = {}
# # foundSomething = 0
# # count = 0
# # for line in mylist:
# #     mydictionary[line.name] = line.link
# #
# # aString = input()
# # # vocabLibrary = []
# # # resultList = []
# # # while aString != "-1":
# # #     a = aString.split(':')
# # #     vocabLibrary.append(a[0])
# # #     resultList.append(a[1])
# # #     aString = input()
# # #
# # # for line in vocabLibrary:
# # #     print(line)
# #
# #
# # for item in mydictionary:
# #     if aString == item:
# #         count += 1
# #         foundSomething = 1
# #         print(str(count) + ". " + item + ": " + mydictionary[item])
# #
# # if foundSomething == 0:
# #     print("Cannot find anything matches this string")
#
# # aStr = input()
# #
# # for line in mylist:
# #     if aStr == line.name:
# #         print(line.name, line.link)
#
# ## ------------------ Match similar strings -------------------------
# #
# # aStr = input().lower()
# # if "_" in aStr:
# #     alist = aStr.split("_")
# #     bStr = ""
# #     count = 1
# #     for item in alist:
# #         if count < len(alist):
# #             bStr = bStr + item + " "
# #         else:
# #             bStr = bStr + item
# #         count += 1
# #     aStr = bStr
# #
# # for line in mylist:
# #     if aStr in line.name.lower():
# #         print(line.name, line.link)
# #
# #
#
# ## ------------------ Guessing the Unit -------------------------
# # a = input()
# # b = input()
# #
# # def isInt(aString):
# #     try:
# #         float(aString)
# #         return float(aString)
# #     except ValueError:
# #         return False
# #
# # c = isInt(b)
# #
# # if c != False:
#
#
# ## ------------------ Match similar strings (Miss something / has bugs) -------------------------
#
# # aStr = input().lower()
# # keywordList = []
# # if "_" in aStr:
# #     keywordList = aStr.split("_")
# #
# # if " " in aStr:
# #     keywordList = aStr.split()
# #
# # # print(keywordList[0])
# #
# # listHeader = [[] for i in range(0, len(keywordList) + 1)]
# # print(len(listHeader))
# #
# # for line in mylist:
# #     listHeader[0].append(line.name)
# #
# # count = 0
# # while count < len(keywordList):
# #     for word in listHeader[count]:
# #         if keywordList[count] in word.lower():
# #             listHeader[count + 1].append(word)
# #     count += 1
# #
# #
# # finalList = []
# # listHeader.reverse()
# #
# # for li in listHeader:
# #     print(li)
# #
# # i = 0
# # while i < len(listHeader) - 1:
# #     for item in listHeader[i]:
# #         if item not in finalList:
# #             finalList.append(item)
# #     i += 1
# #
# #
# # for item in finalList:
# #     print(item)
#
#
# ## ------------------ Match similar strings (still missing something) -------------------------
#
# # aStr = input().lower()
# # keywordList = []
# # if "_" in aStr:
# #     keywordList = aStr.split("_")
# # elif " " in aStr:
# #     keywordList = aStr.split()
# # else:
# #     keywordList.append(aStr)
# #
# # # print(keywordList[0])
# #
# # listHeader = [[] for i in range(0, len(keywordList) + 1)]
# # print(len(listHeader))
# #
# # for line in mylist:
# #     listHeader[0].append(line.name)
# #
# # count = 0
# # while count < len(keywordList):
# #     for word in listHeader[count]:
# #         i = count
# #         while i < len(keywordList):
# #             if keywordList[i] in word.lower() and word not in listHeader[count + 1]:
# #                 listHeader[count + 1].append(word)
# #             i += 1
# #     count += 1
#
# # count = 0
# # while count < len(keywordList):
# #     for word in listHeader[count]:
# #         if keywordList[count] in word.lower() and word not in listHeader[count + 1]:
# #             listHeader[count + 1].append(word)
# #     count += 1
#
# # finalList = []
# # listHeader.reverse()
# #
# # for li in listHeader:
# #     print(li)
# #
# # i = 0
# # while i < len(listHeader) - 1:
# #     for item in listHeader[i]:
# #         if item not in finalList:
# #             finalList.append(item)
# #     i += 1
# #
# #
# # for item in finalList:
# #     print(item)
#
#
# ## ------------------ Match similar strings (should be fine) -------------------------
#
# # aStr = input().lower()
# # keywordList = []
# #
# # if "_" in aStr:
# #     keywordList = aStr.split("_")
# # elif " " in aStr:
# #     keywordList = aStr.split()
# # else:
# #     keywordList.append(aStr)
# #
# # listHeader = [[] for i in range(0, len(keywordList))]
# # listHeader2 = [[] for i in range(0, len(keywordList)+1)]
# #
# #
# # for i in range(len(keywordList)):
# #     for word in mylist:
# #         if keywordList[i] in word.name.lower():
# #             listHeader[i].append(word.name)
# #
# #
# # for line in mylist:
# #     count = 0
# #     for li in listHeader:
# #         if line.name in li:
# #             count += 1
# #     listHeader2[count].append(line.name)
# #
# # listHeader2.reverse()
# # finalList = []
# # i = 0
# # while i < len(listHeader2) - 1:
# #     for item in listHeader2[i]:
# #         finalList.append(item)
# #     i += 1
# #
# # if not finalList:
# #     print("No results")
# # else:
# #     for item in finalList:
# #         print(item)
#
#
# # def suggestion(aStr):
# #
# #     keywordList = []
# #
# #     if "_" in aStr:
# #         keywordList = aStr.split("_")
# #     elif " " in aStr:
# #         keywordList = aStr.split()
# #     else:
# #         keywordList.append(aStr)
# #
#     # wordsMatched = [[word] for i in range(len(keywordList)) for word in vocabLibrary
#     #                 if ('_'+keywordList[i] in word.lower())
#     #                 or (' '+keywordList[i] in word.lower())
#     #                 or ('-'+keywordList[i] in word.lower())
#     #                 or (keywordList[i] == word.lower()[0:len(keywordList[i])])]
# #
# #     listHeader2 = [[] for i in range(len(keywordList))]
# #
# #     for line in vocabLibrary:
# #         count = 0
# #         for li in wordsMatched:
# #             if line in li:
# #                 count += 1
# #         if count > 0:
# #             listHeader2[count-1].append(line)
# #
# #     listHeader2.reverse()
# #
# #     finalList = [item for i in range(len(listHeader2)) for item in listHeader2[i]]
# #
# #     if not finalList:
# #         print("No results")
# #     else:
# #         for item in finalList:
# #             print(item)
#
# ## ------------------ Use dictionary to store the vocab library -------------------------
#
# # def suggestion(aStr, type):
# #     # A list to store the search terms
# #     keywordList = []
# #
# #     # Split the search term
# #     if "_" in aStr:
# #         keywordList = aStr.split("_")
# #     elif " " in aStr:
# #         keywordList = aStr.split()
# #     else:
# #         keywordList.append(aStr)
# #
# #     # Search for vocabularies from the dictionary that contain at least one word that similar / identical to
# #     # the search terms, if search for similar vocabularies, only the first few letters of the vocabulary will be
# #     # matched with the search term: e.g. if the search term is 'a', only the vocabularies starting with 'a' will be
# #     # considered
# #     wordsMatched = [key for i in range(len(keywordList)) for key in myDictionary
# #                     if ('_'+keywordList[i] in key.lower())
# #                     or (' '+keywordList[i] in key.lower())
# #                     or ('-'+keywordList[i] in key.lower())
# #                     or (keywordList[i] == key.lower()[0:len(keywordList[i])])]
# #
# #     listHeader2 = [[] for i in range(len(keywordList))]
# #
# #     # Allocate the vocabularies in the wordsMatched list to separate lists according to their number of words that match
# #     # the search term
# #     for key1 in myDictionary:
# #         count = 0
# #         for key2 in wordsMatched:
# #             if key1 == key2:
# #                 count += 1
# #         if count > 0:
# #             listHeader2[count-1].append([key1, myDictionary[key1][1]])
# #
# #     listHeader2.reverse()
# #
# #     # Sort the list by 1. their similarity to the search term 2. the times they have been chosen by users
# #     finalList = [item[0] for i in range(len(listHeader2)) for item in (sorted(listHeader2[i], key=itemgetter(1), reverse=True))]
# #
# #
# #
# #     # Print the result
# #     num = 1
# #     if not finalList:
# #         print("No results")
# #     else:
# #         print("Result:")
# #         for key in finalList:
# #             print(str(num), key + ' : ' + myDictionary[key][0], str(myDictionary[key][1]))
# #             num += 1
# #
# #     # Let the user choose the vocabulary that match their expectation and record their choice
# #     while True:
# #         chosen = input("Which one did you choose?")
# #         try:
# #             n = int(chosen)
# #             myDictionary[finalList[n-1]][1] += 1
# #             break
# #         except ValueError:
# #             print("Please enter a number")
# #         except IndexError:
# #             print("Please enter a number within the range")
#
#
# ## ------------------ Try to use rules set -------------------------
# def suggestion(aStr):
#
#     # A list to store the search terms
#     keywordList = []
#
#     inputterm = aStr.split(': ')
#
#     metaData = inputterm[0]
#     dataValue = inputterm[1]
#
#     # Split the search term
#     if "_" in metaData:
#         keywordList = metaData.split("_")
#     elif " " in metaData:
#         keywordList = metaData.split()
#     else:
#         keywordList.append(metaData)
#
#     # Search for vocabularies from the dictionary that contain at least one word that similar / identical to
#     # the search terms, if search for similar vocabularies, only the first few letters of the vocabulary will be
#     # matched with the search term: e.g. if the search term is 'a', only the vocabularies starting with 'a' will be
#     # considered
#     wordsMatched = [key for i in range(len(keywordList)) for key in myDictionary
#                     if ('_'+keywordList[i] in key.lower())
#                     or (' '+keywordList[i] in key.lower())
#                     or ('-'+keywordList[i] in key.lower())
#                     or (keywordList[i] == key.lower()[0:len(keywordList[i])])]
#
#     listHeader2 = [[] for i in range(len(keywordList))]
#
#     # Allocate the vocabularies in the wordsMatched list to separate lists according to their number of words that match
#     # the search term
#     for key1 in myDictionary:
#         count = 0
#         for key2 in wordsMatched:
#             if key1 == key2:
#                 count += 1
#         if count > 0:
#             listHeader2[count-1].append([key1, myDictionary[key1][1]])
#
#     listHeader2.reverse()
#
#     # Sort the list by 1. their similarity to the search term 2. the times they have been chosen by users 3. if there
#     # are any rules that can apply on them
#     # for i in range(len(listHeader2)):
#     #     listHeader2[i].sort(key=itemgetter(1), reverse=True)
#     #     listHeader2[i] = ruleset(type, listHeader2[i])
#
#     finalList = [item for i in range(len(listHeader2)) for item in listHeader2[i]]
#
#     # print(finalList)
#
#     # Print the result
#     num = 1
#     if not finalList:
#         print("No results")
#     else:
#         print("Result:")
#         for item in finalList:
#             # if num > 10:
#             #     break
#             print(str(num), item[0])
#             num += 1
#
#         # while True:
#         #     chosen = input("Which one did you choose? ")
#         #     try:
#         #         n = int(chosen)
#         #         myDictionary[finalList[n-1]][1] += 1
#         #         break
#         #     except ValueError:
#         #         print("Please enter a number")
#         #     except IndexError:
#         #         print("Please enter a number within the range")
#
#
# def ruleset(typeOfResearch, vocablist):
#     rulesForSearch = {'land': ['soil', 'clay', 'sand']}
#
#     # If the dictionary does not have any key that match the type of research, return the list in its original order
#     # else re-order the list by the keywords from the dictionary, for the vocabularies that do not contain any of
#     # the keywords, insert them at the back of the list by their original order
#     if typeOfResearch not in rulesForSearch.keys():
#         plist = [v[0] for v in vocablist]
#     else:
#         rules = rulesForSearch[typeOfResearch]
#
#         # If the vocabulary contain at least one of the keywords, put them in the list first
#         plist = []
#         for v in vocablist:
#             for r in rules:
#                 if r.lower() in v[0].lower() and v[0] not in plist:
#                     plist.append(v[0])
#
#         # Then put the rest of the vocabularies to the list
#         for v in vocablist:
#             if v[0] not in plist:
#                 plist.append(v[0])
#
#     return plist
#
#
# def unitRulesApply(vocabList, value):
#     i = 0
#     for key in ruleNum:
#         if key == 'unitMatching':
#             i = ruleNum[key]
#             break
#
#     ruleDict = ruleNum[i]
#
#     setectedVocab = []
#
#     # Checking if the data value is in the range of the unit of that vocabulary
#     for item in vocabList:
#         for rule in ruleDict:
#             if item == rule and value >= rule[0] and value <= rule[1]:
#                 setectedVocab.append(item)
#
#
#
# def checkRecord(term, vocab):
#
#     # Check if this pair exists in the dictionary
#     # If yes, chosen +1
#     # If no, create a new pair
#     # Return the number of chosen
#
#     a = []
#
#
#
# #
# # def addUnitRule(name, min, max, unit):
# #
# #     try:
# #         int(min)
# #         int(max)
# #     except ValueError:
# #         print("Please enter a number for min / max")
# #
# #     newrule = name + '__' + str(min) + '__' + str(max) + '__' + unit + '\n'
# #     vocabList = []
# #     try:
# #         file = open('dataMatching.txt', 'r')
# #         for line in file:
# #             vocabList.append(line)
# #         vocabList.append(newrule)
# #         file.close()
# #
# #         file = open('dataMatching.txt', 'w')
# #         for line in vocabList:
# #             file.write(line)
# #         file.close()
# #
# #     except FileNotFoundError:
# #         print("File not found")
# #         sys.exit()
#
#
#
#
# # Keep asking for input until '-1' is entered
# while True:
#     a = input("Search: ").lower()
#     if a == '-1':
#         break
#     suggestion(a)
#
#     # addUnitRule(input("Name: "), input("Min: "), input("Max: "), input("Unit: "))
#
#     print("-------------------------------------------------\n")
#
#
#
#

# import datetime
# import pytz
# from pytz import reference
# from pytz import timezone
# import isodate
# from pytz import all_timezones
# import pendulum
# from isodate import tzinfo
#
# # b = isodate.tz_isoformat()
# x = datetime.datetime(2018, 8, 16, 0, 0, 0, tzinfo=timezone('Australia/Brisbane'))
# y = datetime.datetime(2018, 1, 15, 0, 0, tzinfo=<isodate.tzinfo.Utc object>)
# localtime = reference.LocalTimezone()
#
# # for zone in all_timezones:
# #     if 'Australia' in zone:
# #         print(zone)
#
# print(x)
# print(localtime.tzname(x))
# print(datetime.datetime.utcnow())

# date = datetime.datetime.now()
# date = date.replace(tzinfo=pytz.utc)
# date = pendulum.timezone('UTC').convert(date)
# pendulum_date = pendulum.instance(date)
# print(date, pendulum_date)
# (2018, 5, 27, 0, 0, tzinfo=datetime.timezone.utc)
# datetime.datetime(1969, 12, 31, 17, 0, tzinfo=<DstTzInfo 'US/Pacific' PST-1 day, 16:00:00 STD>)
# print(pacific_date)
# datetime.datetime(2018, 5, 27, 0, 0, tzinfo=<isodate.tzinfo.Utc object at 0x7fa426a2e860>)



# print(unit_dict['@graph'][150])
# print(unit_dict.keys())

# @id + qudt:symbol + rdfs:label + qudt:abbreviation

import json
#
# with open('property.json', 'r') as f:
#     vocab_dict = json.load(f)
# count = 1
# for i in vocab_dict['@graph']:
#     if 'rdfs:label' in i and 'qudt:unit' in i:
#         print(count, i['@id'], i['rdfs:label'], i['qudt:unit'])
#         count += 1
#     elif 'rdfs:label' in i:
#         print(count, i['@id'], i['rdfs:label'])
#         count += 1





import json

# with open('qudt-unit.json', 'r') as f:
#     unit_dict = json.load(f)
#
# d = {}
#
# for i in unit_dict['@graph']:
#     if 'rdfs:label' in i:
#         if 'qudt:symbol' in i:
#             if 'qudt:abbreviation' in i:
#                 if i['qudt:symbol'] != i['qudt:abbreviation']:
#                     d[i['rdfs:label']] = (i['@id'], [i['qudt:symbol'], i['qudt:abbreviation']])
#                 else:
#                     d[i['rdfs:label']] = (i['@id'], [i['qudt:symbol']])
#             else:
#                 d[i['rdfs:label']] = (i['@id'], [i['qudt:symbol']])
#         elif 'qudt:abbreviation' in i:
#             d[i['rdfs:label']] = (i['@id'], [i['qudt:abbreviation']])
#         elif i['rdfs:label'] not in d.keys():
#             d[i['rdfs:label']] = (i['@id'], ['No symbol'])


# with open('unit.json', 'r') as f2:
#     vocab_dict = json.load(f2)
#
# for i in vocab_dict['@graph']:
#     if 'rdfs:label' in i:
#         if 'qudt:symbol' in i:
#             if 'qudt:abbreviation' in i:
#                 if i['qudt:symbol'] != i['qudt:abbreviation']:
#                    print(i['rdfs:label'], i['@id'], '["', i['qudt:symbol'], '", "', i['qudt:abbreviation'], '"]')
#                 else:
#                     print(i['rdfs:label'], i['@id'], '["', i['qudt:symbol'], '"]')
#             else:
#                 print(i['rdfs:label'], i['@id'], '["', i['qudt:symbol'], '"]')
#         elif 'qudt:abbreviation' in i:
#             print(i['rdfs:label'], i['@id'], '["', i['qudt:abbreviation'], '"]')


# http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/


# import json
# with open('property.json', 'r') as f:
#     vocab_dict = json.load(f)
#
# for item in vocab_dict['@graph']:
#     if 'rdfs:label' in item:
#         print(item['rdfs:label'])

# print(vocab_dict['@graph'])


# a_dict = {'a': 123, 'b': 456}
# b_dict = {'c': 789}
#
# c_dict = dict(list(a_dict.items()) + list(b_dict.items()))
# print(c_dict)

# import Dictionary_Reading
#
# dict = Dictionary_Reading.read_simple_json("units_of_measure.json")
#
# for key in dict:
#     if key == "cubic metres per cubic metre":
#         print(dict[key])

# a = "°"
# print(a)

# a = ['Ω', 'β', 'Δ', 'μ']
#
# with open('testing.txt', encoding="utf8") as f:
#     for line in f:
#         print(line)

# import datetime
# import isodate
#
# print(datetime.datetime(2018, 5, 27, 0, 0, tzinfo=))


# datetime.datetime(2018, 5, 27, 0, 0, tzinfo=<isodate.tzinfo.Utc object at 0x7fa426a2e860>)

# a = ['abc ABC abcABC']
# print([x.lower() for x in a])

# import re
#
# keys_list = ['10cm', 'water', 'temp', '12343']
# bridge_list = []
# for key in keys_list:
#     if not re.search('\d+', key):
#         bridge_list.append(re.sub("[^A-Za-z]", "", key))
#     else:
#         bridge_list.append(key)
# print(bridge_list)

# print(re.sub("[^A-Za-z]", "", 'abc123asdf'))


with open("API.json") as f:
    json_file = json.load(f)
    for key in json_file:
        print(key)












