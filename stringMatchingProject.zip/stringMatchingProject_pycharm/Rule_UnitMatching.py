

# -------------------------------- Rule Unit Matching --------------------------------------
# INPUT: vocabs_list (a list of vocabs that have at least one word match the keywords), u (full name of the unit)
# OUTPUT: vocabs_list (a list of vocabs with their updated priority num)
#
# For each vocab in the vocabs_list
#   If the unit of the vocab matches the unit of the metadata
#       Increase its priority num by one
# ------------------------------------------------------------------------------------------
def unit_matching(vocabs_list, u):
    for vocab in vocabs_list:
        if vocab[3] in u:
            vocab[4] += 1
    return vocabs_list
