import json
import sys
import requests
import String_CleaningUp


# --------------- Get data from Research Vocabularies Australia through API ------------------
# INPUT: url(the header of the url that can link to the web page of the vocab) + js (the API link in JSON format)
# OUTPUT: my_dict (a dictionary with the vocabulary names, units and links)
#
# This function can get data through API from Research Vocabularies Australia
# Data will be received in JSON format
#       > It is assumed that all vocabularies from Research Vocabularies Australia have no unit
#       > The name of the vocab must be stored in ['result']['items'][prefLabel']['_value']
#       > The link of the vocab must be stored in ['result']['items']['_about']
#       > Since the link of the vocab did not lead to the web page with CSS, the input url will be added to the head of
#         this link
# --------------------------------------------------------------------------------------------
def get_vocabs_from_rva(url, js):
    my_dict = {}
    while True:
        response = requests.get(js)
        r = json.loads(response.text)
        for i in r['result']['items']:
            link = url + i['_about']
            key = '@' + i['prefLabel']['_value'] + ' none'
            my_dict[key] = {'@label': i['prefLabel']['_value'], '@link': link, '@unit': "none"}
        try:
            js = r['result']['next']
        except:
            return my_dict


# ------------------------------ Read the JSON files from CSIRO registry ------------------------------
# INPUT: filename: the name of the JSON file that want to be read
# OUTPUT: a dictionary with the vocabulary names, units and links
#
#
# *************** This function can read the json files with the following format: ***************
# 1. The data of the vocabularies is paired with the name '@graph'
# 2. For each vocab:
#       > '@rdfs:label' pairs with the name of the vocab (can be string or list of strings)
#       > '@qudt:unit' pairs with the unit of the vocab, must be an url and have the unit name as the last
#          element of the url (can be dictionary or list of dictionaries)
#       > '@id' pairs with the link to the vocab
#
# The vocabs are stored in different formats in these JSON file
# 1. Name pair with key '@rdfs:label' directly, e.g. '@rdfs:label': 'air temperature'
# 2. Multiple names pair with key '@rdfs:label', e.g. '@rdfs:label': ['air temperature', 'average air temperature']
# 3. Name hided inside a dictionary that pair with '@rdfs:label', e.g. '@rdfs:label': {'@lang': 'en',
#    '@value': 'air temperature'}
# 4. Name pair with key 'skos:prefLabel' directly, e.g. 'skos:prefLabel': 'air temperature'
#
# The units are stored in different formats as well
# 1. Unit directly pair with 'qudt:unit',
#    e.g. 'qudt:unit': 'http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius'
# 2. Multiple units pair with key 'qudt:unit',
#    e.g. 'qudt:unit': ['http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius',
#    'http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeKevin']
# ************************************************************************************************
#
# --------------------------------------------------------------------------------------------------------
def read_json_vocab_dictionary(filename):
    my_dict = {}
    try:
        with open(filename, 'r') as f:
            vocab_dict = json.load(f)

        for item in vocab_dict['@graph']:
            if 'rdfs:label' in item:
                if type(item['rdfs:label']) == str:
                    if 'qudt:unit' in item:
                        if type(item['qudt:unit']) == list:
                            for i in item['qudt:unit']:
                                u = i['@id'].split('/')[-1]
                                u = u.replace('unit#', '')
                                u = String_CleaningUp.get_unit_from_vocab(u)
                                my_key = '@' + item['rdfs:label'] + ' ' + u
                                my_dict[my_key] = {'@label': item['rdfs:label'], '@link': item['@id'], '@unit': u}
                        else:
                            u = item['qudt:unit']['@id'].split('/')[-1]
                            u = u.replace('unit#', '')
                            u = String_CleaningUp.get_unit_from_vocab(u)
                            my_key = '@' + item['rdfs:label'] + ' ' + u
                            my_dict[my_key] = {'@label': item['rdfs:label'], '@link': item['@id'], '@unit': u}
                    else:
                        my_key = '@' + item['rdfs:label'] + ' none'
                        my_dict[my_key] = {'@label': item['rdfs:label'], '@link': item['@id'], '@unit': "none"}
                elif type(item['rdfs:label']) == list:
                    for key in item['rdfs:label']:
                        if type(key) == str:
                            if 'qudt:unit' in item:
                                if type(item['qudt:unit']) == list:
                                    for i in item['qudt:unit']:
                                        u = i['@id'].split('/')[-1]
                                        u = u.replace('unit#', '')
                                        u = String_CleaningUp.get_unit_from_vocab(u)
                                        my_key = '@' + key + ' ' + u
                                        my_dict[my_key] = {'@label': key, '@link': item['@id'], '@unit': u}
                                else:
                                    u = item['qudt:unit']['@id'].split('/')[-1]
                                    u = u.replace('unit#', '')
                                    u = String_CleaningUp.get_unit_from_vocab(u)
                                    my_key = '@' + key + ' ' + u
                                    my_dict[my_key] = {'@label': key, '@link': item['@id'], '@unit': u}
                            else:
                                my_key = '@' + key + ' none'
                                my_dict[my_key] = {'@label': key, '@link': item['@id'], '@unit': "none"}
                elif type(item['rdfs:label']) == dict:
                    if 'qudt:unit' in item:
                        if type(item['qudt:unit']) == list:
                            for i in item['qudt:unit']:
                                u = i['@id'].split('/')[-1]
                                u = u.replace('unit#', '')
                                u = String_CleaningUp.get_unit_from_vocab(u)
                                my_key = '@' + item['rdfs:label']['@value'] + ' ' + u
                                my_dict[my_key] = {'@label': item['rdfs:label']['@value'], '@link': item['@id'], '@unit': u}
                        else:
                            u = item['qudt:unit']['@id'].split('/')[-1]
                            u = u.replace('unit#', '')
                            u = String_CleaningUp.get_unit_from_vocab(u)
                            my_key = '@' + item['rdfs:label']['@value'] + ' ' + u
                            my_dict[my_key] = {'@label': item['rdfs:label']['@value'], '@link': item['@id'], '@unit': u}
                    else:
                        my_key = '@' + item['rdfs:label']['@value'] + ' none'
                        my_dict[my_key] = {'@label': item['rdfs:label']['@value'], '@link': item['@id'], '@unit': "none"}
            elif 'skos:prefLabel' in item:
                if 'qudt:unit' in item:
                    if type(item['qudt:unit']) == list:
                        for i in item['qudt:unit']:
                            u = i['@id'].split('/')[-1]
                            u = u.replace('unit#', '')
                            u = String_CleaningUp.get_unit_from_vocab(u)
                            my_key = '@' + item['skos:prefLabel']['@value'] + ' ' + u
                            my_dict[my_key] = {'@label': item['skos:prefLabel']['@value'], '@link': item['@id'], '@unit': u}
                    else:
                        u = item['qudt:unit']['@id'].split('/')[-1]
                        u = u.replace('unit#', '')
                        u = String_CleaningUp.get_unit_from_vocab(u)
                        my_key = '@' + item['skos:prefLabel']['@value'] + ' ' + u
                        my_dict[my_key] = {'@label': item['skos:prefLabel']['@value'], '@link': item['@id'], '@unit': u}
                else:
                    my_key = '@' + item['skos:prefLabel']['@value'] + ' none'
                    my_dict[my_key] = {'@label': item['skos:prefLabel']['@value'], '@link': item['@id'], '@unit': "none"}

            my_dict = check_repeat(my_dict)
    except:
        print('ERROR: File not found, file name =', filename)
    return my_dict


# ---------------------- Get vocabs from JSON files ----------------------------
# INPUT: get_api (a boolean that indicate if the APIs need to be used to get data)
# OUTPUT: --
#
# ************************ The JSON files **************************
# The JSON files may not be the most updated ones.
# ******************************************************************
#
# Read the Text file 'dict_names.txt' to get all JSON files' name
# Call function read_json_vocab_dictionary for each JSON file's name
# Get the vocab dict and add it to the dictionary vocabs_dict
# Call function write_to_json to produce a new JSON file with all vocabularies
#
# If want to read data through APIs as well,
# Read the JSON file 'API.json' that contains all links to the web
# Call function get_vocabs_from_rva() to get the vocabularies
# ------------------------------------------------------------------------------
def get_vocabs_from_json(get_api):
    try:
        vocabs_dict = {}
        with open('dict_names.txt') as f:
            for line in f:
                a_dict = read_json_vocab_dictionary(line.strip())
                for key in a_dict:
                    vocabs_dict[key] = a_dict[key]

            if get_api:
                with open("API.json") as f2:
                    json_file = json.load(f2)
                    for key in json_file:
                        b_dict = get_vocabs_from_rva(json_file[key][0], json_file[key][1])
                        for key2 in b_dict:
                            if key2 not in vocabs_dict.keys():
                                vocabs_dict[key2] = b_dict[key2]

        write_to_json(vocabs_dict)
    except:
        print('No dictionary can be found')
        sys.exit()


# ------------------------ Create a new JSON file -----------------------------
# INPUT: my_dict (a dictionary with all vocabs from the JSON files)
# OUTPUT: --
#
# Write the content of mt_dict to a new JSON file 'vocab_dictionary.json'
# This JSON file will only contain the necessary information
# i.e. Vocab's name, Vocab's link, and Vocab's unit
# -----------------------------------------------------------------------------
def write_to_json(my_dict):
    with open('vocab_dictionary.json', 'w') as f:
        json.dump(my_dict, f)


# ------------------------- Delete the repeated vocab -------------------------
# INPUT: my_dict (a dictionary with all vocabs from the JSON files)
# OUTPUT: new_dict (a dictionary with no repeated vocab)
# *** Repeated vocab means a vocab that has 'none' and 'unit' as its unit ***
# *** If the vocab has multiple unit than it is not a repeated vocab ***
# -----------------------------------------------------------------------------
def check_repeat(my_dict):
    for vocab_key in my_dict:
        if my_dict[vocab_key]['@unit'] != 'none':
            check_key = '@' + my_dict[vocab_key]['@label'] + ' none'
            if check_key in my_dict.keys():
                my_dict[check_key] = {'@label': '', '@link': '', '@unit': "DELETE"}

    new_dict = {}
    for vocab_key in my_dict:
        if my_dict[vocab_key] != {'@label': '', '@link': '', '@unit': "DELETE"}:
            new_dict[vocab_key] = my_dict[vocab_key]
    return new_dict
