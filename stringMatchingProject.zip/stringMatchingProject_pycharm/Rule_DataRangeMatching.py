import json


# ------------------------------ Rule value Matching --------------------------------------
# INPUT: vocabs_list (list of vocabs), value (input value from user), unit (input unit from user)
# OUTPUT: vocabs_list (a list of vocabs with their updated priority num)
#
# Read the dataRangeMatching.json
# For each vocab in the vocabs_list
#   Check if this vocab is included in the dataRangeMatching file
#       If yes, check if the value is in a specific range
#           If yes, increase its priority num by 1
# ------------------------------------------------------------------------------------------
def data_matching(vocabs_list, value, unit):
    try:
        value = float(value)
        with open('dataRangeMatching.json') as f:
            data_range_dictionary = json.load(f)

        if not data_range_dictionary:
            return vocabs_list
        else:
            for vocab in vocabs_list:
                search_key = vocab[1] + ' ' + vocab[3]
                for data_range_key in data_range_dictionary:
                    if search_key == data_range_key:
                        if data_range_dictionary[data_range_key][1] >= value >= data_range_dictionary[data_range_key][0]:
                            if unit == ['none'] or data_range_dictionary[data_range_key][2] in unit:
                                vocab[4] += 1
            return vocabs_list
    except:
        return vocabs_list
