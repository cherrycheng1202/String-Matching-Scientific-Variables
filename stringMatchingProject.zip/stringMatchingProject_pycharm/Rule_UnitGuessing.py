import json


# ------------------------------------ Unit guessing --------------------------------------
# INPUT: vocabs_list (the list of vocabularies), metadata_list (a list with all keywords from metadata)
#        , a_value (data value provided by the user)
# OUTPUT: vocabs_list ((the list of vocabularies)
#
# ***** This function can only deal with float or integer type of data value *****
#
# Read JSON file unitRange.json and get all data from there to a list
# Check each key from the JSON file
# If the keywords match then then check if the value is in a specific range, if yes, get the unit
# ------------------------------------------------------------------------------------------
def guess_unit(vocabs_list, metadata_list, a_value):
    try:
        value = float(a_value)

        with open('unitRange.json') as f:
            unit_range_dictionary = json.load(f)

        possible_unit = list()

        for key1 in unit_range_dictionary:
            for metadata_key in metadata_list:
                if metadata_key.lower() in key1.lower():
                    for key2 in unit_range_dictionary[key1]:
                        for metadata_key2 in metadata_list:
                            if metadata_key2.lower() in key2.lower():
                                for key3 in unit_range_dictionary[key1][key2]:
                                    if unit_range_dictionary[key1][key2][key3][0] <= value <= unit_range_dictionary[key1][key2][key3][1]:
                                        possible_unit.append([key1, key2, key3])

        if len(possible_unit) > 0:
            for vocab in vocabs_list:
                for unit in possible_unit:
                    if vocab[3] in unit[2] and unit[0].lower() in vocab[1].lower() and unit[1].lower() in vocab[1].lower():
                        vocab[4] += 1

        return vocabs_list

    except:
        return vocabs_list
