import json
import sys


# ---------------------------------- JSON file reading -------------------------------------
# INPUT: filename (name of the JSON file)
# OUTPUT: my_dict (a dictionary that contains all contents of that JSON file)
#
# If the file does not exist, display an error message and quit
# ------------------------------------------------------------------------------------------
def read_simple_json(filename):
    try:
        with open(filename, 'r', encoding="utf8") as f:
            my_dict = json.load(f)
        return my_dict
    except:
        print("ERROR: File not found, file name =", filename)
        sys.exit()


# ------------------------------ Vocab JSON file reading -----------------------------------
# INPUT: filename (name of the JSON file)
# OUTPUT: my_dict (a dictionary that contains all contents of that JSON file)
#
# If the file does not exist, display an error message and quit
# ------------------------------------------------------------------------------------------
def read_vocabs(filename):
    try:
        my_dict = dict()
        with open(filename, 'r', encoding="utf8") as f:
            json_file = json.load(f)

        for key in json_file:
            my_dict[key] = [json_file[key]['@label'], json_file[key]['@link'], json_file[key]['@unit']]
        return my_dict
    except:
        print("ERROR: File not found, file name =", filename)
        sys.exit()


# ---------------------------------- TEXT file reading -------------------------------------
# INPUT: filename (name of the TEXT file)
# OUTPUT: my_list (a list contains all contents of that TEXT file)
#
# If the file does not exist, display an error message and quit
# ------------------------------------------------------------------------------------------
def read_simple_text(filename):
    try:
        my_list = []
        with open(filename, 'r', encoding="utf8") as f:
            for line in f:
                my_list.append(line.strip())
        return my_list
    except:
        print("ERROR: File not found, file name =", filename)
        sys.exit()
