import json
import collections


# ---------------------------------- Record modifying --------------------------------------
# INPUT: metadata (metadata input by user), metadata_unit (unit input by user), vocab, unit (unit of the vocab)
# OUTPUT: --
#
# The JSON file recordMatching.json will be opened for read and write
# Check if this metadata, vocab pair has already existed in this file
#   If yes, increase its number by 1
#   If no, create a new pair and set its number as 1
# ------------------------------------------------------------------------------------------
def record_modifying(metadata, metadata_unit, vocab, unit):
    if metadata_unit == '':
        metadata_unit = 'none'

    key = vocab + ' ' + unit
    old_record = False

    with open('recordMatching.json', 'r+', encoding="utf8") as f:
        record_file = json.load(f)

        if key not in record_file.keys():
            record_file[key] = [[metadata, metadata_unit, 1]]
        else:
            for line in record_file[key]:
                if len(line[0]) == len(metadata) and collections.Counter(line[0]) == collections.Counter(metadata) \
                        and metadata_unit == line[1]:
                    line[2] += 1
                    old_record = True
                    break
            if not old_record:
                record_file[key].append([metadata, metadata_unit, 1])

        f.seek(0)
        json.dump(record_file, f)
