from django.shortcuts import render
from stringMatching.search_py.Main import *


# Create your views here.
def index(request):
    return render(request, 'stringMatching/home.html', {'error': ''})
	
def result(request):
	metadata = request.GET['metadata']
	data = request.GET['data']
	unit = request.GET['unit']
	
	if metadata.strip() == "":
		return render(request, 'stringMatching/home.html', {'error': 'Name cannot be empty'})
	else:
		vocab_list = search(metadata, data, unit)
		new_list = list()
		
		if vocab_list[1] != 'No result':
			for line in vocab_list[1]:
				formal_name = form_formal_text(vocab_list[0][0], line[1], line[3])
				new_list.append([formal_name, line])
		else:
			new_list = ['No result']
		
		return render(request, 'stringMatching/result.html', {'searchFor': metadata, 'searchResult': new_list, 'unit': unit})

def choice(request):
    if request.method == 'POST':
        print('*' * 50)
        print(request.POST)
        print('*' * 50)
        vote = request.POST.get("vote", "")
        metadata = request.POST.get("metadata", "")
        unit = request.POST.get("unit", "")
        choice_recording(metadata, unit, vote)
    return render(request, 'stringMatching/home.html')

