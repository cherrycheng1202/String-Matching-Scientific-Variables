import json
import collections


# ------------------------------- Rule Record Matching --------------------------------------
# INPUT: vocabs_list (list of vocabs), a_str (the metadata input by user), a_unit (the unit input by user)
# OUTPUT: vocabs_list (a list of vocabs with their updated priority num)
#
# Read the recordMatching.json
# For each vocab in the vocabs_list
#   Create a key in format: [metadata, unit, vocab, vocab_unit]
#   Check if this key is included in the recordMatching file
#        If yes, increase its priority num by 1
# -------------------------------------------------------------------------------------------
def record_matching(vocabs_list, metadata_list, a_unit):
    if a_unit == '':
        a_unit = 'none'

    with open("stringMatching/search_py/recordMatching.json") as f:
        record_file = json.load(f)
	
    for i in range(len(metadata_list)):
        metadata_list[i] = metadata_list[i].lower()

    for vocab in vocabs_list:
        key = vocab[1] + ' ' + vocab[3]
        if key in record_file.keys():
            for line in record_file[key]:
                if len(line[0]) == len(metadata_list) and collections.Counter(line[0]) \
                        == collections.Counter(metadata_list) and a_unit == line[1]:
                    vocab[4] += (line[2] // 10)

    return vocabs_list

