import re
from stringMatching.search_py.Dictionary_Reading import *


# ------------------------------- Metadata clearing up --------------------------------------
# INPUT: a_str (metadata input by user), a_data (data value input by user), a_unit (unit input by user)
# OUTPUT: [keys_list, a_data, v[1], must_include] (a list with the separated keys from metadata, the data, full name of
#         the unit and the keyword(s) that must be included in the vocabulary)
#
# Check if the metadata is formed by multiple keywords
# If yes, separate them and put them into a list
# ***** This function can only get the words that are separated by " ", "_", ", " or "/" from the metadata *****
#
# Check if the keywords are formed by multiple words again, this time check for the format "Word1Word2", e.g. "AvgTemp"
# Call function get_unit() to get the full name of the input unit
#
# Find out the keywords that must be included in the vocabulary
#   >> The unit and the keywords that contain number will be seen as a minor keyword and "nice to have", which may not
#      be included in the vocabulary. e.g. "045cm", ""
#   >> Other keywords
# ------------------------------------------------------------------------------------------
def cleaning_up_metadata(a_str, a_data, a_unit):
    check = [' ', '_', ', ', '/']
    keys_list = [a_str]

    for char in check:
        keys_list = remove_special_char(keys_list, char)

    v = get_unit(keys_list, a_unit)
    m_list = v[2]
    keys_list = v[0]
    keys_list = remove_stop_words(keys_list)
    v = v[1]
    bridge_list = []

    # --------------------------- Split word by lower/upper letter ---------------------------
    # Check if the keyword is formed by multiple words and are separated by lower/upper letter
    # If yes, split them and append each keyword to the bridge_list
    # Remove the original, non-split keyword from teh keys_list and add the contents from bridge_list to the keys_list
    # ----------------------------------------------------------------------------------------
    for key in keys_list:
        for i in range(len(key) - 1):
            if key[i].islower() and key[i+1].isupper() and key not in m_list:
                bridge_list.append([key, re.findall('[a-zA-Z][^A-Z]*', key)])
                break

    for key in bridge_list:
        if key[0] != v[0]:
            keys_list.remove(key[0])
            keys_list += key[1]

    m_list = remove_adj(keys_list, m_list)
    must_include = []

    # ---------------- Find the must-included keywords and the minor keywords ----------------
    # Check each keyword
    # If the keyword did not contain any number, put it in the must_include list
    # If the keyword contain number(s), put it in the m_list
    # ----------------------------------------------------------------------------------------
    for key in keys_list:
        if not re.search('\d+', key) and len(key) > 1 and key not in m_list:
            must_include.append(key)
        elif re.search('\d+', key) or len(key) <= 1 and key not in m_list:
            m_list.append(key)

    return [keys_list, a_data, v[1], must_include, m_list]


# ---------------------------- Remove special characters -----------------------------------
# INPUT: keys_list (the list of keywords), char (the special character want to be removed)
# OUTPUT: keys_list (the list of keywords)
#
# Remove the special character from the keywords
# ------------------------------------------------------------------------------------------
def remove_special_char(keys_list, char):
    bridge_list = []
    for key in keys_list:
        if char in key:
            w = key.split(char)
            for item in w:
                if item != '' and item not in bridge_list:
                    bridge_list.append(item)
        else:
            bridge_list.append(key)
    keys_list = bridge_list
    return keys_list


# ----------------------------------- Remove adj -------------------------------------------
# INPUT: metadata (the list of keywords), m_list (the list of minor keywords)
# OUTPUT: m_list (the list of minor keywords)
#
# Check if there are any adj in the keywords, if yes, addend the adj to the m_list
# ------------------------------------------------------------------------------------------
def remove_adj(metadata, m_list):
    adj_dict = read_simple_json('stringMatching/search_py/adj.json')
    for word in metadata:
        for key in adj_dict:
            for item in adj_dict[key]:
                if word.lower() == key.lower() or word.lower() == item.lower() and word not in m_list:
                    m_list.append(word)
    return m_list


# ---------------------- Get unit full name (Unit provided by user) ------------------------
# INPUT: metadata (metadata input by user), a_unit (unit input by user)
# OUTPUT: [metadata, unit] (a list with the separated keys from metadata and the full name of the unit)
#
# Read JSON file units_of_measure.json and get all data from there to a dictionary
#
# Check the symbols of each unit from the JSON file and match the unit input by user to them
# If the unit match the symbols then get the full name of that symbol
#
# Also check if there is any unit in the metadata, if yes, add that unit to the minor_keywords list
# ------------------------------------------------------------------------------------------
def get_unit(metadata, a_unit):
    unit_dict = read_simple_json('stringMatching/search_py/units_of_measure.json')
    unit = [a_unit, []]
    if unit == ['', []]:
        unit = ['none', ['none']]
    else:
        for key in unit_dict:
            if unit[0] == key:
                unit[1].append(key)
            else:
                for k in unit_dict[key][0]:
                    if unit[0] == k:
                        unit[1].append(key)
        if len(unit[1]) < 1:
            unit = [a_unit, [a_unit]]

    minor_keywords = []

    for key in unit_dict:
        for k in unit_dict[key][0]:
            if k in metadata and k not in minor_keywords:
                minor_keywords.append(k)

    return [metadata, unit, minor_keywords]


# ---------------------------- Remove stop words from metadata ------------------------------
# INPUT: keys_list (key words from metadata)
# OUTPUT: new_list (a list of key words except the stop words)
#
# Read TEXT file stop_words.txt and get all data from there to a list
# Check if the word from the metadata is not included in the stop words list, append this word to the new keys list
# ------------------------------------------------------------------------------------------
def remove_stop_words(keys_list):
    stop_words_list = read_simple_text('stringMatching/search_py/stop_words.txt')
    new_list = []
    for key in keys_list:
        if key not in stop_words_list:
            new_list.append(key)
    return new_list


# ----------------------------- Get unit full name (Vocab) ----------------------------------
# INPUT: unit_name (unit of the vocab)
# OUTPUT: [keys_list, a_data, v[1]] (a list with the separated keys from metadata, the data and full name of the unit)
#
# Read JSON file units_of_measure.json and get all data from there to a dictionary
#
# Check the symbols of each unit from the JSON file and match the unit input by user to them
# If the unit match the symbols then get the full name of that symbol
# ------------------------------------------------------------------------------------------
def get_unit_from_vocab(unit_name):
    unit_dict = read_simple_json('stringMatching/search_py/units_of_measure.json')
    unit = ''
    url = 'http://registry.it.csiro.au/def/environment/unit/_' + unit_name
    url2 = 'http://registry.it.csiro.au/def/environment/unit/' + unit_name
    url3 = 'http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/' + unit_name

    for key in unit_dict:
        if url == unit_dict[key][1] or url2 == unit_dict[key][1] or url3 == unit_dict[key][1]:
            unit = key

    return unit
