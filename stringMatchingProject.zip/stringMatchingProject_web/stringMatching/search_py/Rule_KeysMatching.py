

# -------------------------------- Rule key Matching -------------------------------
# INPUT: metadata_list (list with all keywords from the metadata), my_dictionary (all vocabularies from the JSON file),
#        must_include_list (list with the keywords that must be included in the vocabulary)
# OUTPUT: final_list (a list with vocabs that have at least one word matches the keys from metadata)
#
# ***** This function can only match the keyword and the vocabulary with the following formats *****
# 'temp' in 'temperature' = TRUE            ||              'temp' in 'hightemp' = FALSE
# 'temp' in 'temp' = TRUE                   ||              'temp' in 'water' = FALSE
# 'temp' in '_temp' = TRUE                  ||              'temp' in '123temp' = FALSE
# 'temp' in ' temp' = TRUE                  ||
# 'temp' in '-temp' = TRUE                  ||
# **************************************************************************************************
#
# For the vocab includes one of the keys, store it in the list 1
# For the vocab includes two of the keys, store it in the list 2
# ...
# For the vocab includes n of the keys, store it in the list n
#
# According to the list number, give each vocabulary a priority number. i.e. 1 for vocabularies that in list 1; 2 for
# vocabularies that in list 2
#
# Check each found vocabulary, each of them must include all keywords from must_include_list in order to be appended to
# the final_list
# ----------------------------------------------------------------------------------
def key_matching(metadata_list, my_dictionary, must_include_list):
    new_list = metadata_list

    words_matched = [key for i in range(len(new_list)) for key in my_dictionary
                     if ('_' + new_list[i].lower() in my_dictionary[key][0].lower())
                     or (' ' + new_list[i].lower() in my_dictionary[key][0].lower())
                     or ('-' + new_list[i].lower() in my_dictionary[key][0].lower())
                     or (new_list[i].lower() == my_dictionary[key][0].lower()[0:len(new_list[i])])]

    list_header2 = [[] for i in range(len(new_list))]

    for key1 in my_dictionary:
        count = 0
        for key2 in words_matched:
            if key1 == key2:
                count += 1
        if count > 0:
            list_header2[count-1].append([key1, my_dictionary[key1][0], my_dictionary[key1][1], my_dictionary[key1][2], count])

    final_list = []
    for i in range(len(list_header2)):
        for item in list_header2[i]:
            count = 0
            for key in must_include_list:
                if key.lower() in item[1].lower():
                    count += 1
            if count == len(must_include_list):
                final_list.append(item)

    return final_list
