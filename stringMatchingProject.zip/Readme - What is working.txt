----------------------------------------------------------------- String Matching Scientific Variables -----------------------------------------------------------------
--------------------------------------------------------------------------- What is working ----------------------------------------------------------------------------

This project was written in Python 3. The web-based version was created using Django 2.1

To run the PyCharm version of project, run the Main.py.
To run the web-based version of project, in the cmd / terminal move to the directory of the folder which contains the file manage.py in file stringMatchingProject and use "python manage.py runserver" or "python manage.py runserver 8080" to run the project. Type http://127.0.0.1 or http://127.0.0.1:8080/ in the web broswer to use the application.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

SUMMARY

This program can:
1.  Get the vocbaularies from different CSIRO registry JSON files or Research Vocabularies Australia APIs and put them into a JSON file call 'vocab_dictionary.json' with only the necessary information.
2.  The input metadata will be checked and cleanup
3.  Keywords from the metadata will be classified as 'must-include', 'minor' or 'useless'
4.  A score is given to each of the vocabulary
5.  Vocabularies will be filtered according to their similarity to the metadata first (Rule keys matching)
6.  Rule data range matching
7.  Rule unit guessing
8.  Rule units matching
9.  Rule record matching
10. Record the user's choice of vocabulary
11. Narrow down the list to show only the best matched vocabularies

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

This project will take the vocabularies from the JSON files downloaded from CSIRO registry website, create a new JSON file, 'vocab_dictionary.json', to contain these vocabularies alongside with their name, link, and unit. This new JSON file was created because the original JSON files contained too much unnecessary data and were too complex to read. If a new JSON dictionary file wants to be added, put this new JSON dictionary file to the folder and add its name to the TEXT file 'dict_names.txt', then run function get_vocabs_from_json(boolean) [a boolean must be entered as a representation of if the function needs to also get the vocabularies through the APIs as well: True = yes, False = no] the script 'Dictionary_API.py'. The contents of the new JSON dictionary file will be added to the 'vocab_dictionary.json' file.
	>> The format of the vocabularies stored in 'vocab_dictionary.json' file would be "@Vocab Unit": {"@label": "Vocab", "@link": "Link", "@unit": "Unit"}
	e.g. {"@water temperature Degree Fahrenheit": {"@label": "water temperature", "@link": "http://registry.it.csiro.au/def/environment/property/water_temperature", 			     "@unit": "Degree Fahrenheit"}}

There is a scoring system for this program, each vocabulary will be given a score and this score will be raised or dropped after the rules are applied to the vocabularies. A minimum score will be set according to the number of words included in the metadata. The minimum score will be raised if a unit is provided to the user, and will be dropped if there is any minor or useless keywords in the metadata.
	e.g. If 'soil_temp_in_10cm' is the metadata, '' is the value and 'degC' is the unit
	>> First the minimum score will be set to 4 because this metadata is formed by 3 words 'soil', 'temp', 'in' and '10cm'
	>> Then the minimum score will be decreased by 2 because '10cm' is a minor keyword and 'in' is a useless keyword
	>> Then the minimum score will be increased by 1 because a unit is provided
	>> Therefore, the final minimum score of this search is 4 - 2 + 1 = 3

The first part of this project is to clean up the metadata input by the user. If the metadata is made up by multiple words, it is necessary to split them so the program can match each of the keyword with the vocabularies. The keywords of the metadata will be classified as "must-included keywords", "minor keywords" or "useless". Words that are classified as "must-included keywords" must be included in the vocabularies; as "minor keywords" means they are nice to be included but it's fine if they are not; and any words that are classified as "useless" will be removed from the metadata. In addition, in this part the program will try to replace the unit provided by the user (if any) with its full name; if there are more than one unit that use the same symbol, all full names of these units will be added to the list. 

The second part of this project is to find out all vocabularies that have words match the input metadata. Only the vocabularies that include all keywords that are classified as "must-included keywords" will be selected. Each selected vocabulary will be given a score to represent their similarity to the metadata, the higher means the more similar.
	e.g. If 'soil_temp_in_10cm' is the metadata
	>> Vocabulary 'wind speed' will be given a 0 as its score because it has no word matched the metadata
	>> Vocabulary 'air temperature' will be given 1 as its score because it has one word matched the metadata
	>> Vocabulary 'soil temperature' will be given 2 as its score because it has two words matched the metadata

The third part of this project is to apply different rules to the selected vocabularies. Each time a rule is applied on a vocabulary, only their score will be changed. Rules that are included in this project:
   1. Data range matching
       >> This rule will only be used when a data value is provided by the user.
       >> Check if the data value provided by the user is in the data range for each vocabulary, if it is in the range
          and the unit matches (if any), then that vocabulary will be given a higher score.
       >> The data ranges of the vocabularies should be recorded in the JSON file 'dataRangeMatching.json'
       >> The format of the data store in 'dataRangeMatching.json' should be:
          {"VocabName Unit": [Min, Max, "Unit"]}
          e.g. {"iron (III) concentration Percent": [0, 100, "Percent"]}
   2. Unit guessing
       >> This rule will only be used when a value is provided by the user but with no unit provided.
       >> Check if the metadata is in a specific research field, if there is data for this research field, match them
       >> This rule will guess the unit of the input metadata and give the vocabularies that with this unit a higher
          score.
       >> The data of the research field, unit and range are stored in the JSON file 'unitRange.json'
       >> The format of the data store in 'unitRange.json' should be:
          {"researchDetail": {"researchField": {"Unit": [Min, Max]}}}
          e.g. {"Temperature": {"water": {"Degree Celsius": [10, 35]}}}
   3. Units matching
       >> This rule will only be used when a unit is provided by the user.
       >> Check if the unit of each vocabulary matches the unit provided, if yes, give that vocabulary a higher score
   4. Record matching
       >> Check the search history, if there are similar searches before check the result to see the number of user
          that prefer this metadata-vocabulary pair.
       >> For each ten users prefer that result, add one to the score of that vocabulary
       >> The search history is store in the JSON file 'recordMatching.json'
       >> The format of the data store in 'recordMatching.json' should be:
          {"VocabName Unit": [[["Keyword 1", "Keyword 2", ..., "Keyword n"], "UnitProvided", TimesOfBeingChosen]]}
          e.g. {"air temperature Degree Celsius": [[["avg", "temp"], "none", 3]]}

The fourth part of this project is to record the user's choice for their search. The program will allow the user to input their choice of vocabulary and record only the keywords of the metadata and the unit with the chosen vocabulary. The search history will be written to the JSON file 'recordMatching.json'. The program would first search for the "VocabName Unit", then [[MetadataKeywords], UnitProvided]. If nothing can be found the program will create a new record for that search, else the program will increase the TimesOfBeingChosen by one.

After all necessary rules are applied to the vocabularies, the program will sort these vocabularies by their score, the highest score will come first. This program will only return the vocabularies that have their score higher than the minimum score.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Demostration in PyCharm (Use Cases):

1.
Name:

Process finished with exit code 0

=> Name of the metadata must be entered for the program to run

---------------------------------------------

2.
Name: temp
Value:
Unit:

[['temp'], '', ['none'], ['temp'], []]
1 soil temperature in Degree Celsius [ soil temperature (http://registry.it.csiro.au/sandbox/environment/property/soil_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
2 air temperature in Degree Celsius [ air temperature (http://registry.it.csiro.au/def/environment/property/air_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
3 dew point temperature in Degree Celsius [ dew point temperature (http://registry.it.csiro.au/def/environment/property/dew_point_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
4 sea water temperature in Degree Celsius [ sea water temperature (http://registry.it.csiro.au/def/environment/property/sea_water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
5 water temperature in Degree Celsius [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
6 apparent temperature [ apparent temperature (http://data.sense-t.org.au/registry/def/sop/_AT) none () ]
7 internal temperature [ internal temperature (http://data.sense-t.org.au/registry/def/sop/_InternalTemperature) none () ]
8 processor temperature [ processor temperature (http://data.sense-t.org.au/registry/def/sop/processor_temperature) none () ]
9 soil temperature [ soil temperature (http://data.sense-t.org.au/registry/def/sop/soil_temperature) none () ]
10 temperature index [ temperature index (http://data.sense-t.org.au/registry/def/sop/temperature_index) none () ]
11 water temperature in Degree Fahrenheit [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Fahrenheit (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeFahrenheit) ]
Best match:

=> Only the metadata was entered; therefore, all vocabularies that include 'temp' will be listed out
=> [['temp'], '', ['none'], ['temp'], []] = [['metadata'], 'value', ['unit'], ['must_include'], ['minor keyword']]
    
---------------------------------------------

3.
Name: AvgTemp
Value:
Unit:

[['Avg', 'Temp'], '', ['none'], ['Temp'], ['Avg']]
1 Average air temperature in Degree Celsius [ air temperature (http://registry.it.csiro.au/def/environment/property/air_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
2 Average water temperature in Degree Celsius [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
3 Average soil temperature in Degree Celsius [ soil temperature (http://registry.it.csiro.au/sandbox/environment/property/soil_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
4 Average dew point temperature in Degree Celsius [ dew point temperature (http://registry.it.csiro.au/def/environment/property/dew_point_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
5 Average sea water temperature in Degree Celsius [ sea water temperature (http://registry.it.csiro.au/def/environment/property/sea_water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
6 Average apparent temperature [ apparent temperature (http://data.sense-t.org.au/registry/def/sop/_AT) none () ]
7 Average internal temperature [ internal temperature (http://data.sense-t.org.au/registry/def/sop/_InternalTemperature) none () ]
8 Average processor temperature [ processor temperature (http://data.sense-t.org.au/registry/def/sop/processor_temperature) none () ]
9 Average soil temperature [ soil temperature (http://data.sense-t.org.au/registry/def/sop/soil_temperature) none () ]
10 Average temperature index [ temperature index (http://data.sense-t.org.au/registry/def/sop/temperature_index) none () ]
11 Average water temperature in Degree Fahrenheit [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Fahrenheit (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeFahrenheit) ]
Best match:

=> AvgTemp as the metadata, as it was formed by two words 'Avg' and 'Temp' it would be splited.
=> 'Avg' is a minor keyword (recorded in the minor_Keys.json); therefore, the vocabularies may not need to include this word
=> 'Temp' is a must-include keyword; therefore, the vocabularies must include this word
=> According to the recordMatching.json file, 30 previous users thought the best match for the metadata 'AvgTemp' was 'Average air temperature in Degree Celsius' and 20 previous users thought the best match was 'Average water temperature in Degree Celsius'. Therefore, the score of these two vocabularies would be increased.

---------------------------------------------

4.
Name: water_temp
Value:
Unit:

[['water', 'temp'], '', ['none'], ['water', 'temp'], []]
1 sea water temperature in Degree Celsius [ sea water temperature (http://registry.it.csiro.au/def/environment/property/sea_water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
2 water temperature in Degree Celsius [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
3 water temperature in Degree Fahrenheit [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Fahrenheit (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeFahrenheit) ]
Best match:

=> water_temp as the metadata, as it was formed by two words 'water' and 'temp' it would be splited.
=> Both of the words are the must-include keywords; therefore, the vocabularies must include these words

---------------------------------------------

5.
Name: water_temp
Value:
Unit: degC

[['water', 'temp'], '', ['Degree Celsius'], ['water', 'temp'], []]
1 sea water temperature in Degree Celsius [ sea water temperature (http://registry.it.csiro.au/def/environment/property/sea_water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
2 water temperature in Degree Celsius [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
Best match: 

=> water_temp as the metadata, as it was formed by two words 'water' and 'temp' it would be splited.
=> Both of the words are the must-include keywords; therefore, the vocabularies must include these words
=> There was a unit provided as well; therefore, the vocabularies must use this unit as their unit

---------------------------------------------

6.
Name: water_temp
Value: 95
Unit:

[['water', 'temp'], '95', ['none'], ['water', 'temp'], []]
1 water temperature in Degree Fahrenheit [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Fahrenheit (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeFahrenheit) ]
2 sea water temperature in Degree Celsius [ sea water temperature (http://registry.it.csiro.au/def/environment/property/sea_water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
3 water temperature in Degree Celsius [ water temperature (http://registry.it.csiro.au/def/environment/property/water_temperature) Degree Celsius (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/DegreeCelsius) ]
Best match: 

=> water_temp as the metadata, as it was formed by two words 'water' and 'temp' it would be splited.
=> Both of the words are the must-include keywords; therefore, the vocabularies must include these words
=> There was a value provided but with no unit
=> There was no matching data from dataRangeMatching.json file
=> According to unitRange.json file, if the metadata included keyword 'Temperature' and 'Water', and the value is in the range from 60 to 95, the possible unit for this metadata is 'Degree Fahrenheit'. Therefore, the score of the vocabulary 'water temperature in Degree Fahrenheit' would be increased.

---------------------------------------------

7.
Name: iron
Value: 0.23
Unit: 

[['iron'], '0.23', ['none'], ['iron'], []]
1 iron (III) concentration in MilliGrams per Kilogram [ iron (III) concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_ferric_concentration) MilliGrams per Kilogram (http://registry.it.csiro.au/def/environment/unit/_MilligramsPerKilogram) ]
2 iron concentration in Percent [ iron concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_concentration) Percent (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/Percent) ]
3 iron concentration in MilliGrams per Kilogram [ iron concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_concentration) MilliGrams per Kilogram (http://registry.it.csiro.au/def/environment/unit/_MilligramsPerKilogram) ]
4 iron (III) concentration in Percent [ iron (III) concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_ferric_concentration) Percent (http://registry.it.csiro.au/def/qudt/1.1/qudt-unit/Percent) ]
5 iron (III) concentration in MicroGrams per Litre [ iron (III) concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_ferric_concentration) MicroGrams per Litre (http://registry.it.csiro.au/def/environment/unit/_MicrogramsPerLitre) ]
6 iron (III) concentration in MilliGrams per Litre [ iron (III) concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_ferric_concentration) MilliGrams per Litre (http://registry.it.csiro.au/def/environment/unit/_MilligramsPerLitre) ]
7 iron (II) concentration in MilliGrams per Litre [ iron (II) concentration (http://registry.it.csiro.au/sandbox/soil/soil-property/iron_ferrous_concentration) MilliGrams per Litre (http://registry.it.csiro.au/def/environment/unit/_MilligramsPerLitre) ]
8 iron sulfide concentration [ iron sulfide concentration (http://registry.it.csiro.au/def/environment/property/iron_sulfide_concentration) none () ]
9 iron sulphide concentration [ iron sulphide concentration (http://registry.it.csiro.au/def/environment/property/iron_sulfide_concentration) none () ]
Best match: 

=> There was a value provided but with no unit
=> According to the dataRangeMatching.json file, there was a vocabulary "iron (III) concentration MilliGrams per Kilogram" which contained the word 'iron' and had a data range 0 to 5 which matched the provided vaule; therefore, the score of the vocabulary "iron (III) concentration MilliGrams per Kilogram" would be increased

---------------------------------------------

8.
Name: 2016/17 Summer Rainfall
Value: 
Unit: 

[['2016', '17', 'Summer', 'Rainfall'], '', ['none'], ['Summer', 'Rainfall'], ['2016', '17']]
No result

=> No vocabulary matched this metadata; therefore, no result would be provided

