----------------------------------------------------------------- String Matching Scientific Variables ------------------------------------------------------------------
------------------------------------------------------------------ What is not working and Suggestions ------------------------------------------------------------------

SUMMARY

This program cannot:
1. Read input data value that is not float or integer
2. Read JSON files or use APIs that are not in specific format
3. Identify keywords that are not included in the file 'minor_keys.json' or do not contain number as the 'minor keyword'
4. Cover data from every research field

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

This program cannot read the value if the user input anything other than a float or integer as the data value. The rule data range matching will check if the type of the data value is float or integer, and this rule will not be applied on the vocabularies if the data value is not a number. However, there may be other data types for the data value returned by the sensors, such as datetime and string.

Suggestion:
Create a function to check the data type of the data value, and according to the different data types, different rules should be applied to the vocabularies. For example, if the data type is found as datetime, the function should be able to figure out the area by the timezone of the datetime.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Secodnly, this program cannot read JSON files or use APIs that are not in a specific format. JSON files that are directly download from the website or get through the APIs are all in different formats, and the program can only read the vocabularies used for this program were come from CSIRO registry and Research Vocabularies Australia. The JSON files downloaded from CSIRO registry website contains different formats in itself as well, there may be some vocabularies that have been missed. These files may not be the most updated one as the website was keeping on improving and creating more files. In addition, the program currently can take vocabularies from seven JSON files, all of these JSON files were downloaded from http://registry.it.csiro.au/. However, there are still a lot of vocabularies that have not been included in the downloaded JSON files.

Suggestion:
The best way is to connect to the vocabulary server with some methods that can provide the real-time data, like APIs.

Another way is to create database (not a very good one because the data stored in the database is not real-time and needs manually updating, but database can ensure that the formats of the vocabularies stored are consistent). Using a database to store the data may be able to improve the reading speed for the program, as indexes can be created and the program will not need to load the whole content from the JSON file to the memory and check the vocabularies one by one to see if they can be used.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The file 'minor_keys.json' does not contain a lot of data, and it is not enough for the program to identify every minor keywords from the metadata. In addition, the files 'dataRangeMatching.json', 'recordMatching.json', and 'unitRange.json' do not have enough information for the program to find out the best vocabularies for the search. Therefore, all of these files should be extend and more data should be included in them.

Suggestion:
More data should be added to these files. Since these files only contain the sample data set at the moment, after more data sets are added it may be found that the format of these file does not fit the data. In this case, modification may need to be done to ensure that all data can be stored and accessed easily.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The rule record matching would check the search histroy and identify if the metadata had already been searched before, and if it had the program would check the the vocabularies that had been chosen by the previous users and how many time those vocabularies had been chosen for that metadata. At the moment, the rule would increase the score of the vocabulary by 1 for every 10 previous users had chosen that vocabulary. Since the volumn of data and how actually the user will use this program is still unknown, this number '10' may not be sutiable for this rule after actual implementation. The idea of setting the number as '10' at the moment was to consider if only several users thought the vocabulary that was not listed on top was the best match of the metadata, it could be a special case and only fit in several situations. However, if there were many users thought that vocabulary was the best match, the program would need to reconsider the order of these vocabularies. '10 users' was considered to be a fair number of users, therefore, the score of the vocabulary would increase by 1 if there were 10 previous users thought that vocabulary was the best match.

Suggestion:
This number '10' can be changed easily in Rule_RecordMatching.py. The performance of this program should be recorded and analysed to identify its effectiveness and efficency, if this number had reduced the accuracy of the result, as '10 users' may not have enough power to change the order of the vocabularies, it should be changed.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

The rule data range matching and unit guessing was very similar: data range matching was to check the data range of a specific vocabulary with unit to see if the value provided was in that range; unit guessing was to check a specific research field and the data range of the units to see if the value provided was in any of the ranges.

Suggestion:
Maybe both of the rule can be combined as one

------------------------------------------------------------------------------------------------------------------------------------------------------------------------

New rules can be added to the project, like check the type of the research.